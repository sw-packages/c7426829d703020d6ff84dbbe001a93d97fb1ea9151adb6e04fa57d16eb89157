/*

@Copyright Barrett Adair 2016-2017
Distributed under the Boost Software License, Version 1.0.
(See accompanying file LICENSE.md or copy at http://boost.org/LICENSE_1_0.txt)

*/

#ifndef BOOST_CLBL_TRTS_DETAIL_CORE_HPP
#define BOOST_CLBL_TRTS_DETAIL_CORE_HPP

#include <boost/callable_traits/detail/utility.hpp>
#include <boost/callable_traits/detail/traits.hpp>
#include <boost/callable_traits/detail/function_object.hpp>
#include <boost/callable_traits/detail/function.hpp>
#include <boost/callable_traits/detail/pmf.hpp>
#include <boost/callable_traits/detail/pmd.hpp>

#endif // #ifndef BOOST_CLBL_TRTS_DETAIL_CORE_HPP
